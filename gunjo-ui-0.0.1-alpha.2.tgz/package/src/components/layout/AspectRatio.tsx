"use client"

import * as React from "react"
import * as AspectRatioPrimitive from "@radix-ui/react-aspect-ratio"

const AspectRatio = AspectRatioPrimitive.Root

export type AspectRatioProps = React.ComponentPropsWithoutRef<
    typeof AspectRatioPrimitive.Root
>

export { AspectRatio }
