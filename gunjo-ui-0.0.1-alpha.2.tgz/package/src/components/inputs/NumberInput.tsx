"use client"

import * as React from "react"
import {
    IconChevronDown as ChevronDown,
    IconChevronUp as ChevronUp,
    IconMinus as Minus,
    IconPlus as Plus,
} from "@tabler/icons-react";

import { cn } from "../../lib/utils"

export interface NumberInputProps
    extends Omit<React.InputHTMLAttributes<HTMLInputElement>, "value" | "onChange" | "type"> {
    value?: number
    onValueChange?: (value: number) => void
    min?: number
    max?: number
    step?: number
    incrementLabel?: string
    decrementLabel?: string
    /**
     * `"spinner"` (default) renders the conventional input with stacked up/down
     * chevrons. `"stepper"` renders a horizontal `− [value] +` control, the
     * layout commerce quantity pickers expect. The native `<input type=number>`
     * keeps its spinbutton semantics in both layouts. (#169)
     */
    layout?: "spinner" | "stepper"
    /** Optional visible label rendered above the control and associated via `htmlFor`. */
    label?: React.ReactNode
    /** Optional helper text under the control, wired via `aria-describedby`. */
    description?: React.ReactNode
}

const NumberInput = React.forwardRef<HTMLInputElement, NumberInputProps>(
    (
        {
            className,
            value,
            onValueChange,
            min,
            max,
            step = 1,
            incrementLabel = "Increment",
            decrementLabel = "Decrement",
            layout = "spinner",
            disabled,
            onBlur,
            id,
            label,
            description,
            "aria-describedby": ariaDescribedby,
            ...props
        },
        ref
    ) => {
        const reactId = React.useId()
        const hasWrap = Boolean(label || description)
        const controlId = id ?? (hasWrap ? `${reactId}-number` : undefined)
        const descriptionId = description ? `${reactId}-description` : undefined
        const describedBy = [descriptionId, ariaDescribedby].filter(Boolean).join(" ") || undefined
        const wrap = (control: React.ReactElement) =>
            hasWrap ? (
                <div className="flex w-full flex-col gap-1.5">
                    {label ? (
                        <label htmlFor={controlId} className="text-sm font-medium leading-none text-foreground">
                            {label}
                        </label>
                    ) : null}
                    {control}
                    {description ? (
                        <p id={descriptionId} className="text-xs text-muted-foreground">
                            {description}
                        </p>
                    ) : null}
                </div>
            ) : (
                control
            )

        const clamp = React.useCallback(
            (next: number) => {
                let result = next
                if (min !== undefined) result = Math.max(min, result)
                if (max !== undefined) result = Math.min(max, result)
                return result
            },
            [min, max]
        )

        // Hold a draft string while the field is empty/partial ("" / "-") so the
        // user can clear a cell to retype without it snapping back to the old
        // value; commit a number only when the text parses. (#198)
        const [draft, setDraft] = React.useState<string | null>(null)
        const display = draft !== null ? draft : (value ?? "")

        const handleChange = (event: React.ChangeEvent<HTMLInputElement>) => {
            const raw = event.target.value
            const parsed = Number(raw)
            if (raw === "" || raw === "-" || Number.isNaN(parsed)) {
                setDraft(raw)
                return
            }
            setDraft(null)
            onValueChange?.(clamp(parsed))
        }

        const handleBlur = (event: React.FocusEvent<HTMLInputElement>) => {
            // Drop the draft so the display snaps back to the committed value.
            setDraft(null)
            onBlur?.(event)
        }

        const adjust = (delta: number) => {
            const current = value ?? 0
            setDraft(null)
            onValueChange?.(clamp(current + delta))
        }

        const atMax = max !== undefined && (value ?? 0) >= max
        const atMin = min !== undefined && (value ?? 0) <= min

        if (layout === "stepper") {
            return wrap(
                <div
                    className={cn(
                        "inline-flex items-center rounded-md border border-input bg-transparent shadow-sm focus-within:outline-none focus-within:ring-1 focus-within:ring-ring",
                        disabled && "opacity-50 pointer-events-none",
                        className
                    )}
                    data-slot="number-input"
                    data-layout="stepper"
                >
                    <button
                        type="button"
                        tabIndex={-1}
                        onClick={() => adjust(-step)}
                        disabled={disabled || atMin}
                        className="flex h-9 w-9 shrink-0 items-center justify-center rounded-l-md text-muted-foreground hover:bg-muted hover:text-foreground disabled:opacity-50"
                        aria-label={decrementLabel}
                    >
                        <Minus className="h-4 w-4" />
                    </button>
                    <input
                        ref={ref}
                        id={controlId}
                        type="number"
                        inputMode={step % 1 === 0 ? "numeric" : "decimal"}
                        value={display}
                        onChange={handleChange}
                        onBlur={handleBlur}
                        disabled={disabled}
                        min={min}
                        max={max}
                        step={step}
                        aria-describedby={describedBy}
                        className="h-9 w-12 border-x border-input bg-transparent px-1 py-1 text-center text-sm placeholder:text-muted-foreground focus-visible:outline-none [appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none"
                        {...props}
                    />
                    <button
                        type="button"
                        tabIndex={-1}
                        onClick={() => adjust(step)}
                        disabled={disabled || atMax}
                        className="flex h-9 w-9 shrink-0 items-center justify-center rounded-r-md text-muted-foreground hover:bg-muted hover:text-foreground disabled:opacity-50"
                        aria-label={incrementLabel}
                    >
                        <Plus className="h-4 w-4" />
                    </button>
                </div>
            )
        }

        return wrap(
            <div
                className={cn(
                    "inline-flex items-center rounded-md border border-input bg-transparent shadow-sm focus-within:outline-none focus-within:ring-1 focus-within:ring-ring",
                    disabled && "opacity-50 pointer-events-none",
                    className
                )}
                data-slot="number-input"
            >
                <input
                    ref={ref}
                    id={controlId}
                    type="number"
                    inputMode={step % 1 === 0 ? "numeric" : "decimal"}
                    value={display}
                    onChange={handleChange}
                    onBlur={handleBlur}
                    disabled={disabled}
                    min={min}
                    max={max}
                    step={step}
                    aria-describedby={describedBy}
                    className="h-9 w-full rounded-l-md bg-transparent px-3 py-1 text-sm placeholder:text-muted-foreground focus-visible:outline-none [appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none"
                    {...props}
                />
                <div className="flex flex-col border-l border-input">
                    <button
                        type="button"
                        tabIndex={-1}
                        onClick={() => adjust(step)}
                        disabled={disabled || (max !== undefined && (value ?? 0) >= max)}
                        className="flex h-[18px] w-7 items-center justify-center text-muted-foreground hover:bg-muted disabled:opacity-50"
                        aria-label={incrementLabel}
                    >
                        <ChevronUp className="h-3 w-3" />
                    </button>
                    <div className="h-px bg-input" />
                    <button
                        type="button"
                        tabIndex={-1}
                        onClick={() => adjust(-step)}
                        disabled={disabled || (min !== undefined && (value ?? 0) <= min)}
                        className="flex h-[18px] w-7 items-center justify-center text-muted-foreground hover:bg-muted disabled:opacity-50"
                        aria-label={decrementLabel}
                    >
                        <ChevronDown className="h-3 w-3" />
                    </button>
                </div>
            </div>
        )
    }
)
NumberInput.displayName = "NumberInput"

export { NumberInput }
